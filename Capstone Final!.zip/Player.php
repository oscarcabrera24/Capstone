
<?php // Player.php
  $host = 'localhost';    // shouldn't need to change
  $data = 'yardwork';        // Change as necessary
  $user = 'root';         // Change as necessary
  $pass = 'mysql';         // Change as necessary
  $chrs = 'utf8mb4';
  $attr = "mysql:host=$host;dbname=$data;charset=$chrs";
  $opts =
  [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
  ];

  try {
    $pdo = new PDO($attr, $user, $pass, $opts);
  }
  catch (PDOException $e) {
    throw new PDOException($e->getMessage(), (int)$e->getEmail());
  }

  if (isset($_POST['delete']) && isset($_POST['Name'])) {
    $t_name   = $pdo->quote($_POST['Name']);
    $query  = "DELETE FROM players WHERE Name=$t_name";
    $result = $pdo->query($query);
  }

  if (isset($_POST['Name']) &&
      isset($_POST['Age']) && 
      isset($_POST['Position']) &&  
      isset($_POST['HitRatio'])) {
    $Name   = $pdo->quote($_POST['Name']);
    $Age     = $pdo->quote($_POST['Age']);
    $Position     = $pdo->quote($_POST['Position']);
    $HitRatio     = $pdo->quote($_POST['HitRatio']);
    $query    = "INSERT INTO players VALUES" .
      "($Name,$Age,$Position,$HitRatio)";
    $result = $pdo->query($query);
  }

  echo <<<_END
  <form action="Player.php" method="post"><pre>
    Name: <input type="text" name="Name" required>
      Age <input type="text" name="Age" required>
      Postion <input type="text" name="Position" required>
      Hit Ratio <input type="text" name="HitRatio" required>
      <p><input type="submit" name="submit" value="Submit Data"></p></fieldset>
  </pre></form>
_END;

  $query  = "SELECT * FROM players";
  $result = $pdo->query($query);

  while ($row = $result->fetch()) {
    // create temp strings w/security
    $r1 = htmlspecialchars($row['Name']);
    $r2 = htmlspecialchars($row['Age']);
    $r3 = htmlspecialchars($row['Position']);
    $r4 = htmlspecialchars($row['HitRatio']);


    // output record data and delete button
    echo <<<_END
  <pre>
     Name $r1
     Age $r2
     Postion $r3
     HitRatio $r4
     
  </pre>
  <form action='Player.php' method='post'>
  <input type='hidden' name='delete' value='yes'>
  <input type='hidden' name='Name' value='$r1'>
  <input type='submit' value='delete contact'></form>
_END;
  }
?>